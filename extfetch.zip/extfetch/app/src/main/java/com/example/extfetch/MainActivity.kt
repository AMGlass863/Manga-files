package com.example.extfetch

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.util.IdentityHashMap
import java.util.zip.GZIPInputStream
import rikka.shizuku.Shizuku

class Field(val num: Int, val wire: Int, val v: Long, val b: ByteArray?)
class Found(val apk: String, val fields: List<Field>, val chain: List<List<Field>>)
class Ext(val title: String, val pkg: String, val apk: String, val url: String, val ids: Set<Long>)

// ------------------------------------------------------------ protobuf --
object Pb {
    fun parse(buf: ByteArray): List<Field>? {
        val out = ArrayList<Field>()
        var i = 0
        val n = buf.size

        fun varint(): Long? {
            var r = 0L
            var s = 0
            while (true) {
                if (i >= n || s > 63) return null
                val c = buf[i++].toInt() and 0xff
                r = r or ((c and 0x7f).toLong() shl s)
                if ((c and 0x80) == 0) return r
                s += 7
            }
        }

        while (i < n) {
            val key = varint() ?: return null
            val num = (key ushr 3).toInt()
            val wire = (key and 7).toInt()
            if (num <= 0 || num > 5000) return null
            when (wire) {
                0 -> {
                    val v = varint() ?: return null
                    out.add(Field(num, 0, v, null))
                }
                1 -> {
                    if (i + 8 > n) return null
                    var v = 0L
                    for (k in 7 downTo 0) v = (v shl 8) or (buf[i + k].toLong() and 0xff)
                    i += 8
                    out.add(Field(num, 1, v, null))
                }
                2 -> {
                    val len = varint() ?: return null
                    if (len < 0 || len > (n - i).toLong()) return null
                    val l = len.toInt()
                    out.add(Field(num, 2, 0, buf.copyOfRange(i, i + l)))
                    i += l
                }
                5 -> {
                    if (i + 4 > n) return null
                    i += 4
                    out.add(Field(num, 5, 0, null))
                }
                else -> return null
            }
        }
        return out
    }

    fun text(b: ByteArray): String? {
        if (b.isEmpty()) return null
        return try {
            val s = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
            if (s.all { !it.isISOControl() }) s else null
        } catch (e: CharacterCodingException) {
            null
        }
    }

    fun findEntries(buf: ByteArray, out: MutableList<Found>, chain: List<List<Field>>, depth: Int) {
        val fields = parse(buf) ?: return
        var apk: String? = null
        for (f in fields) {
            if (f.wire == 2) {
                val t = text(f.b!!)
                if (t != null && t.endsWith(".apk")) {
                    apk = t
                    break
                }
            }
        }
        if (apk != null) {
            out.add(Found(apk, fields, chain))
            return
        }
        if (depth < 8) {
            val newChain = ArrayList<List<Field>>(chain)
            newChain.add(fields)
            for (f in fields) if (f.wire == 2) findEntries(f.b!!, out, newChain, depth + 1)
        }
    }

    fun collect(fields: List<Field>, ints: MutableSet<Long>, strs: MutableList<String>, depth: Int = 0) {
        for (f in fields) {
            when (f.wire) {
                0, 1 -> ints.add(f.v)
                2 -> {
                    val t = text(f.b!!)
                    if (t != null) {
                        strs.add(t)
                        val d = t.removePrefix("-")
                        if (d.isNotEmpty() && t.length <= 21 && d.all { it in '0'..'9' }) {
                            try {
                                ints.add(BigInteger(t).toLong())
                            } catch (e: Exception) {
                            }
                        }
                    } else if (depth < 8) {
                        val sub = parse(f.b!!)
                        if (sub != null) collect(sub, ints, strs, depth + 1)
                    }
                }
            }
        }
    }
}

fun gunzipIfNeeded(d: ByteArray): ByteArray {
    if (d.size > 2 && d[0] == 0x1f.toByte() && d[1] == 0x8b.toByte()) {
        return GZIPInputStream(d.inputStream()).use { it.readBytes() }
    }
    return d
}

class NetException(msg: String) : RuntimeException(msg)

fun isNetError(e: Throwable) = e is java.net.UnknownHostException || e is java.net.ConnectException ||
    e is java.net.SocketTimeoutException || e is java.net.NoRouteToHostException

class Backup(val ids: Set<Long>, val names: Map<Long, String>, val repos: List<String>)

fun readBackup(raw: ByteArray): Backup {
    val data = gunzipIfNeeded(raw)
    val ids = HashSet<Long>()
    val names = HashMap<Long, String>()
    val repos = ArrayList<String>()
    val top = Pb.parse(data) ?: return Backup(ids, names, repos)
    for (f in top) {
        if (f.wire != 2) continue
        val sub = Pb.parse(f.b!!) ?: continue
        when (f.num) {
            1 -> sub.firstOrNull { it.num == 1 && it.wire == 0 }?.let { ids.add(it.v) }
            101 -> {
                val name = sub.firstOrNull { it.num == 1 && it.wire == 2 }?.b?.let { Pb.text(it) }
                val sid = sub.firstOrNull { it.num == 2 && it.wire == 0 }?.v
                if (sid != null) {
                    ids.add(sid)
                    if (name != null) names[sid] = name
                }
            }
            106 -> sub.firstOrNull { it.num == 1 && it.wire == 2 }?.b?.let { Pb.text(it) }
                ?.let { repos.add(it.trim()) }
        }
    }
    return Backup(ids, names, repos)
}

// ---------------------------------------------------------------- repo --
fun httpOpen(u: String): HttpURLConnection {
    val c = URL(u).openConnection() as HttpURLConnection
    c.setRequestProperty("User-Agent", "komikku-ext-fetch/1.0")
    c.connectTimeout = 15000
    c.readTimeout = 60000
    c.instanceFollowRedirects = true
    if (c.responseCode != 200) throw RuntimeException("HTTP " + c.responseCode)
    return c
}

fun httpGet(u: String): ByteArray = httpOpen(u).inputStream.use { it.readBytes() }

fun repoBase(u0: String): String {
    val u = u0.trim().trimEnd('/')
    val last = u.substringAfterLast('/')
    return if (last.endsWith(".json") || last.endsWith(".pb")) u.substringBeforeLast('/') else u
}

fun loadPb(data0: ByteArray, wanted: Set<Long>): Pair<List<Ext>, Int> {
    val data = gunzipIfNeeded(data0)
    val found = ArrayList<Found>()
    Pb.findEntries(data, found, emptyList(), 0)
    val under = IdentityHashMap<List<Field>, Int>()
    for (f in found) for (a in f.chain) under[a] = (under[a] ?: 0) + 1
    val out = ArrayList<Ext>()
    for (f in found) {
        val cands = ArrayList<List<Field>>()
        cands.add(f.fields)
        for (a in f.chain.drop(1).reversed()) if ((under[a] ?: 0) <= 3) cands.add(a)
        for (c in cands) {
            val ints = HashSet<Long>()
            val strs = ArrayList<String>()
            Pb.collect(c, ints, strs)
            val hit = ints.filter { it in wanted }.toSet()
            if (hit.isNotEmpty()) {
                val url = if (f.apk.startsWith("http")) f.apk else ""
                val name = Uri.decode(f.apk.substringAfterLast('/'))
                val pkg = strs.firstOrNull { it.contains("extension") && !it.contains(' ') && !it.startsWith("http") } ?: ""
                val title = strs.firstOrNull {
                    it.length >= 3 && !it.startsWith("http") && !it.contains("extension.") &&
                        !it.endsWith(".apk") && it.any { ch -> ch.isLetter() }
                } ?: name
                out.add(Ext(title, pkg, name, url, hit))
                break
            }
        }
    }
    return Pair(out, found.size)
}

fun loadRepo(indexUrl: String, wanted: Set<Long>): Triple<String, List<Ext>, Int> {
    val base = repoBase(indexUrl)
    val errors = ArrayList<String>()
    try {
        val (entries, total) = loadPb(httpGet("$base/index.pb"), wanted)
        if (total > 0) return Triple(base, entries, total)
        errors.add("index.pb had no extensions")
    } catch (e: Exception) {
        if (isNetError(e)) throw NetException(e.toString())
        errors.add("index.pb: " + e.message)
    }
    try {
        val arr = JSONArray(String(httpGet("$base/index.min.json"), Charsets.UTF_8))
        val out = ArrayList<Ext>()
        var total = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val apk = o.optString("apk", "")
            if (apk.isEmpty()) continue
            total++
            val srcs = o.optJSONArray("sources") ?: continue
            val hit = HashSet<Long>()
            for (j in 0 until srcs.length()) {
                val sid = srcs.optJSONObject(j)?.opt("id")?.toString() ?: continue
                try {
                    val v = BigInteger(sid).toLong()
                    if (v in wanted) hit.add(v)
                } catch (e: Exception) {
                }
            }
            if (hit.isNotEmpty()) out.add(Ext(o.optString("name", apk), o.optString("pkg", ""), apk, "", hit))
        }
        return Triple(base, out, total)
    } catch (e: Exception) {
        if (isNetError(e)) throw NetException(e.toString())
        errors.add("index.min.json: " + e.message)
    }
    throw RuntimeException(errors.joinToString("; "))
}

// ------------------------------------------------------------ activity --
typealias RepoResult = Triple<String, List<Ext>, Int>

class DlResult(
    val done: List<String>,
    val failed: List<Pair<String, Ext>>,
    val failedText: List<String>,
    val doneApks: List<String>
)

class LocalApk(val name: String, val uri: Uri, val size: Long)
class InstallItem(val name: String, val uri: Uri)

class MainActivity : Activity() {
    // ---- pages / drawer ----
    private lateinit var prefs: SharedPreferences
    private var themePref = 2                         // 0 Light, 1 Dark, 2 System
    private var isDark = false
    @Volatile private var mode = 0                    // 0 download+install, 1 install only, 2 settings
    private lateinit var titleView: TextView
    private lateinit var pageDownload: LinearLayout
    private lateinit var pageLocal: LinearLayout
    private lateinit var pageSettings: LinearLayout
    private lateinit var scrim: View
    private lateinit var drawer: LinearLayout
    private val drawerItems = ArrayList<TextView>()
    private var drawerOpen = false
    private val titles = arrayOf("ডাউনলোড ও ইনস্টল", "শুধু ইনস্টল", "সেটিংস")

    // ---- install-only page ----
    private lateinit var pickApkBtn: Button
    private lateinit var lStatus: TextView
    private lateinit var lScroll: ScrollView
    private lateinit var lTools: LinearLayout
    private lateinit var lBox: LinearLayout
    private lateinit var lLog: TextView
    private lateinit var installLocalBtn: Button
    private val localItems = ArrayList<LocalApk>()
    private val lDesel = HashSet<Uri>()
    private var pendingInstall: List<InstallItem> = emptyList()

    // ---- download page ----
    private lateinit var pickBtn: Button
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var repoHeader: TextView
    private lateinit var repoBox: LinearLayout
    private lateinit var extHeader: TextView
    private lateinit var extTools: LinearLayout
    private lateinit var extBox: LinearLayout
    private lateinit var missingView: TextView
    private lateinit var logView: TextView
    private lateinit var retryBtn: Button
    private lateinit var installBtn: Button
    private lateinit var dlBtn: Button

    private var bk: Backup? = null
    private val repoData = LinkedHashMap<String, RepoResult?>()
    private val repoSel = HashSet<String>()
    private val netFailed = HashSet<String>()        // repos that failed because of no internet
    private val deselected = HashSet<String>()      // apk names the user unticked
    private var wanted: List<Pair<String, Ext>> = emptyList()
    private var missingIds: List<Long> = emptyList()
    private var busy = false
    private var retryMode = 0                        // 0 hidden, 1 reload repos, 2 retry downloads
    private var failedDl: List<Pair<String, Ext>> = emptyList()
    private val rDone = ArrayList<String>()
    private val rApks = ArrayList<String>()          // APK files ready to install
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) runInstall(pendingInstall)
        else activeStatus().text = "Shizuku-র অনুমতি দেওয়া হয়নি। Shizuku অ্যাপ থেকে এই অ্যাপকে অনুমতি দিন।"
    }
    private var rSkipped: List<String> = emptyList()
    private var rMissing: List<String> = emptyList()
    private var rFailed: List<String> = emptyList()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun matchParent() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun activeStatus(): TextView = if (mode == 1) lStatus else status

    override fun onCreate(savedInstanceState: Bundle?) {
        // ---- theme must be applied before super.onCreate ----
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        themePref = prefs.getInt("theme", 2)
        isDark = when (themePref) {
            0 -> false
            1 -> true
            else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
        setTheme(
            if (isDark) android.R.style.Theme_DeviceDefault_NoActionBar
            else android.R.style.Theme_DeviceDefault_Light_NoActionBar
        )
        super.onCreate(savedInstanceState)

        // ================= download page (আগের স্ক্রিন) =================
        pickBtn = Button(this)
        pickBtn.text = "ব্যাকআপ ফাইল বাছাই করুন (.tachibk)"
        pickBtn.setOnClickListener {
            if (busy) return@setOnClickListener
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, 1)
        }

        status = TextView(this)
        status.textSize = 13f
        status.setPadding(dp(4), dp(8), dp(4), dp(8))
        status.text = "ব্যাকআপ বাছাই করুন। কিছু ইনস্টল হবে না, APK-গুলো Download/extensions ফোল্ডারে জমা হবে।"

        scroll = ScrollView(this)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL

        repoHeader = header("Repo")
        repoBox = LinearLayout(this)
        repoBox.orientation = LinearLayout.VERTICAL

        extHeader = header("Extension")
        extTools = LinearLayout(this)
        extTools.orientation = LinearLayout.HORIZONTAL
        val allBtn = Button(this)
        allBtn.text = "সব বাছাই"
        allBtn.setOnClickListener {
            deselected.clear()
            renderExt()
        }
        val noneBtn = Button(this)
        noneBtn.text = "সব বাদ"
        noneBtn.setOnClickListener {
            for (w in wanted) deselected.add(w.second.apk)
            renderExt()
        }
        extTools.addView(allBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        extTools.addView(noneBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        extBox = LinearLayout(this)
        extBox.orientation = LinearLayout.VERTICAL

        missingView = TextView(this)
        missingView.textSize = 13f
        missingView.setPadding(dp(4), dp(12), dp(4), dp(12))
        missingView.setTextIsSelectable(true)

        logView = TextView(this)
        logView.textSize = 13f
        logView.setTextIsSelectable(true)

        for (v in listOf(repoHeader, repoBox, extHeader, extTools, extBox, missingView, logView)) content.addView(v, matchParent())
        scroll.addView(content)

        retryBtn = Button(this)
        retryBtn.text = "আবার চেষ্টা করুন"
        retryBtn.setOnClickListener {
            if (busy) return@setOnClickListener
            when (retryMode) {
                1 -> retryRepos()
                2 -> retryDownloads()
                else -> {}
            }
        }

        installBtn = Button(this)
        installBtn.text = "Shizuku দিয়ে সব ইনস্টল করুন"
        installBtn.setOnClickListener { installAll() }

        dlBtn = Button(this)
        dlBtn.text = "ডাউনলোড করুন"
        dlBtn.setOnClickListener { startDownload() }

        pageDownload = LinearLayout(this)
        pageDownload.orientation = LinearLayout.VERTICAL
        pageDownload.addView(pickBtn, matchParent())
        pageDownload.addView(status, matchParent())
        pageDownload.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pageDownload.addView(retryBtn, matchParent())
        pageDownload.addView(installBtn, matchParent())
        pageDownload.addView(dlBtn, matchParent())

        // ================= install-only page =================
        pickApkBtn = Button(this)
        pickApkBtn.text = "APK ফাইল বাছাই করুন"
        pickApkBtn.setOnClickListener {
            if (busy) return@setOnClickListener
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            startActivityForResult(i, 2)
        }

        lStatus = TextView(this)
        lStatus.textSize = 13f
        lStatus.setPadding(dp(4), dp(8), dp(4), dp(8))
        lStatus.text = "যে ফোল্ডারে APK আছে (যেমন Download/extensions) সেখান থেকে একসাথে অনেকগুলো ফাইল বাছাই করুন।"

        lScroll = ScrollView(this)
        val lContent = LinearLayout(this)
        lContent.orientation = LinearLayout.VERTICAL

        lTools = LinearLayout(this)
        lTools.orientation = LinearLayout.HORIZONTAL
        val lAll = Button(this)
        lAll.text = "সব বাছাই"
        lAll.setOnClickListener {
            lDesel.clear()
            renderLocal()
        }
        val lNone = Button(this)
        lNone.text = "সব বাদ"
        lNone.setOnClickListener {
            for (a in localItems) lDesel.add(a.uri)
            renderLocal()
        }
        val lClear = Button(this)
        lClear.text = "তালিকা মুছুন"
        lClear.setOnClickListener {
            if (busy) return@setOnClickListener
            localItems.clear()
            lDesel.clear()
            lLog.text = ""
            lLog.visibility = View.GONE
            renderLocal()
            lStatus.text = "তালিকা খালি করা হয়েছে।"
        }
        lTools.addView(lAll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        lTools.addView(lNone, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        lTools.addView(lClear, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        lBox = LinearLayout(this)
        lBox.orientation = LinearLayout.VERTICAL

        lLog = TextView(this)
        lLog.textSize = 13f
        lLog.setTextIsSelectable(true)
        lLog.setPadding(dp(4), dp(12), dp(4), dp(12))

        lContent.addView(lTools, matchParent())
        lContent.addView(lBox, matchParent())
        lContent.addView(lLog, matchParent())
        lScroll.addView(lContent)

        installLocalBtn = Button(this)
        installLocalBtn.text = "Shizuku দিয়ে ইনস্টল করুন (0)"
        installLocalBtn.setOnClickListener {
            val items = localItems.filter { it.uri !in lDesel }.map { InstallItem(it.name, it.uri) }
            startInstall(items)
        }

        pageLocal = LinearLayout(this)
        pageLocal.orientation = LinearLayout.VERTICAL
        pageLocal.addView(pickApkBtn, matchParent())
        pageLocal.addView(lStatus, matchParent())
        pageLocal.addView(lScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pageLocal.addView(installLocalBtn, matchParent())

        // ================= settings page =================
        pageSettings = LinearLayout(this)
        pageSettings.orientation = LinearLayout.VERTICAL
        pageSettings.addView(header("থিম"), matchParent())
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.VERTICAL
        val themeNames = arrayOf("Light", "Dark", "System")
        val ids = IntArray(3)
        for (k in 0..2) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            ids[k] = rb.id
            rb.text = themeNames[k]
            rb.textSize = 15f
            rg.addView(rb, RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        rg.check(ids[themePref])
        rg.setOnCheckedChangeListener { _, checkedId ->
            val idx = ids.indexOf(checkedId)
            if (idx >= 0 && idx != themePref) {
                prefs.edit().putInt("theme", idx).apply()
                intent.putExtra("mode", 2)           // recreate হওয়ার পর সেটিংস পেজেই থাকবে
                recreate()
            }
        }
        pageSettings.addView(rg, matchParent())

        // ================= top bar =================
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        val menuBtn = Button(this)
        menuBtn.text = "☰"
        menuBtn.textSize = 20f
        menuBtn.minWidth = 0
        menuBtn.minimumWidth = 0
        menuBtn.setPadding(dp(16), 0, dp(16), 0)
        menuBtn.setOnClickListener { openDrawer() }
        titleView = TextView(this)
        titleView.textSize = 18f
        titleView.setTypeface(null, Typeface.BOLD)
        titleView.setPadding(dp(12), 0, 0, 0)
        topBar.addView(menuBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        topBar.addView(titleView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ================= main column =================
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(dp(12), dp(24), dp(12), dp(12))
        main.addView(topBar, matchParent())
        for (p in listOf(pageDownload, pageLocal, pageSettings)) {
            main.addView(p, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        // ================= drawer =================
        val frame = FrameLayout(this)
        frame.addView(main, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        scrim = View(this)
        scrim.setBackgroundColor(0x66000000)
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeDrawer() }
        frame.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.setBackgroundColor(if (isDark) 0xFF1F1F1F.toInt() else 0xFFFFFFFF.toInt())
        drawer.elevation = dp(16).toFloat()
        drawer.isClickable = true
        drawer.setPadding(0, dp(24), 0, dp(12))
        val dh = TextView(this)
        dh.text = "মেনু"
        dh.textSize = 20f
        dh.setTypeface(null, Typeface.BOLD)
        dh.setPadding(dp(20), dp(20), dp(20), dp(16))
        drawer.addView(dh, matchParent())
        drawerItems.clear()
        for (k in 0..2) {
            if (k == 2) {
                val line = View(this)
                line.setBackgroundColor(0x33888888)
                drawer.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
            }
            val t = TextView(this)
            t.text = titles[k]
            t.textSize = 16f
            t.setPadding(dp(20), dp(16), dp(20), dp(16))
            t.setOnClickListener {
                if (busy) {
                    Toast.makeText(this, "চলমান কাজ শেষ হওয়া পর্যন্ত অপেক্ষা করুন", Toast.LENGTH_SHORT).show()
                } else {
                    closeDrawer()
                    showMode(k)
                }
            }
            drawerItems.add(t)
            drawer.addView(t, matchParent())
        }
        drawer.translationX = -dp(280).toFloat()
        frame.addView(drawer, FrameLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.MATCH_PARENT))

        setContentView(frame)

        // ---- initial states ----
        showListViews(false)
        logView.visibility = View.GONE
        lLog.visibility = View.GONE
        dlBtn.visibility = View.GONE
        setRetry(0, null)
        installBtn.visibility = View.GONE
        renderLocal()
        showMode(intent.getIntExtra("mode", 0))
        try {
            Shizuku.addRequestPermissionResultListener(permListener)
        } catch (e: Throwable) {
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
        } catch (e: Throwable) {
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer() else super.onBackPressed()
    }

    // ------------------------------------------------------- drawer --
    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        scrim.alpha = 0f
        scrim.visibility = View.VISIBLE
        scrim.animate().alpha(1f).setDuration(200).start()
        drawer.animate().translationX(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        scrim.animate().alpha(0f).setDuration(200).withEndAction { scrim.visibility = View.GONE }.start()
        drawer.animate().translationX(-dp(280).toFloat()).setDuration(220).start()
    }

    private fun showMode(m: Int) {
        mode = m
        pageDownload.visibility = if (m == 0) View.VISIBLE else View.GONE
        pageLocal.visibility = if (m == 1) View.VISIBLE else View.GONE
        pageSettings.visibility = if (m == 2) View.VISIBLE else View.GONE
        titleView.text = titles[m]
        for ((k, t) in drawerItems.withIndex()) {
            t.setBackgroundColor(if (k == m) 0x33888888 else 0)
            t.setTypeface(null, if (k == m) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun header(t: String): TextView {
        val h = TextView(this)
        h.text = t
        h.textSize = 16f
        h.setTypeface(null, Typeface.BOLD)
        h.setPadding(dp(4), dp(14), dp(4), dp(4))
        return h
    }

    private fun showListViews(show: Boolean) {
        val vis = if (show) View.VISIBLE else View.GONE
        for (v in listOf<View>(repoHeader, repoBox, extHeader, extTools, extBox, missingView)) v.visibility = vis
    }

    private fun setRetry(mode: Int, text: String?) {
        retryMode = mode
        retryBtn.visibility = if (mode == 0) View.GONE else View.VISIBLE
        if (text != null) retryBtn.text = text
    }

    private fun setStatus(s: String) = runOnUiThread { activeStatus().text = s }

    // -------------------------------------------------------- scanning --
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 2) {
            if (resultCode == RESULT_OK && data != null && !busy) addLocal(data)
            return
        }

        val uri = data?.data
        if (requestCode == 1 && resultCode == RESULT_OK && uri != null && !busy) {
            busy = true
            pickBtn.isEnabled = false
            dlBtn.visibility = View.GONE
            setRetry(0, null)
            showListViews(false)
            logView.visibility = View.GONE
            installBtn.visibility = View.GONE
            status.text = "ব্যাকআপ স্ক্যান হচ্ছে..."
            Thread {
                try {
                    scan(uri)
                } catch (e: Throwable) {
                    setStatus("ত্রুটি: $e")
                }
                runOnUiThread {
                    busy = false
                    pickBtn.isEnabled = true
                }
            }.start()
        }
    }

    private fun scan(uri: Uri) {
        val raw = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val b = readBackup(raw)
        if (b.ids.isEmpty()) {
            setStatus("ব্যাকআপে কোনো source পাওয়া যায়নি। এটা কি Komikku/Mihon ব্যাকআপ?")
            return
        }
        val repos = b.repos.distinct()
        if (repos.isEmpty()) {
            setStatus("ব্যাকআপে কোনো repo নেই।")
            return
        }
        val data = LinkedHashMap<String, RepoResult?>()
        val net = HashSet<String>()
        var offline = false
        for ((i, r) in repos.withIndex()) {
            if (offline) {
                data[r] = null
                net.add(r)
                continue
            }
            setStatus("Repo পড়া হচ্ছে ${i + 1}/${repos.size}...")
            data[r] = try {
                loadRepo(r, b.ids)
            } catch (e: NetException) {
                offline = true
                net.add(r)
                null
            } catch (e: Exception) {
                null
            }
        }
        runOnUiThread {
            bk = b
            repoData.clear()
            repoData.putAll(data)
            netFailed.clear()
            netFailed.addAll(net)
            deselected.clear()
            repoSel.clear()
            for ((u, d) in data) if (d != null) repoSel.add(u)
            status.text = "ব্যাকআপে source: ${b.ids.size}, repo: ${repos.size}। যেগুলো নেবেন না সেগুলোর টিক তুলে দিন।"
            if (net.isNotEmpty()) {
                status.text = "ইন্টারনেট পাওয়া যায়নি, ${net.size}টা repo পড়া যায়নি। নেট চালু করে আবার চেষ্টা করুন।"
                setRetry(1, "আবার চেষ্টা করুন (${net.size}টা repo)")
            }
            showListViews(true)
            renderRepos()
            renderExt()
            dlBtn.visibility = View.VISIBLE
            scroll.scrollTo(0, 0)
        }
    }

    private fun retryRepos() {
        val b = bk ?: return
        busy = true
        retryBtn.isEnabled = false
        pickBtn.isEnabled = false
        status.text = "আবার চেষ্টা হচ্ছে..."
        Thread {
            val res = LinkedHashMap<String, RepoResult?>()
            val still = HashSet<String>()
            var offline = false
            for (u in netFailed.toList()) {
                if (offline) {
                    still.add(u)
                    continue
                }
                try {
                    res[u] = loadRepo(u, b.ids)
                } catch (e: NetException) {
                    offline = true
                    still.add(u)
                } catch (e: Exception) {
                    res[u] = null
                }
            }
            runOnUiThread {
                for ((u, d) in res) {
                    repoData[u] = d
                    if (d != null) repoSel.add(u)
                }
                netFailed.clear()
                netFailed.addAll(still)
                busy = false
                retryBtn.isEnabled = true
                pickBtn.isEnabled = true
                renderRepos()
                renderExt()
                if (still.isEmpty()) {
                    setRetry(0, null)
                    status.text = "সব repo পড়া হয়েছে।"
                } else {
                    setRetry(1, "আবার চেষ্টা করুন (${still.size}টা repo)")
                    status.text = "এখনও ইন্টারনেট পাওয়া যাচ্ছে না।"
                }
            }
        }.start()
    }

    private fun renderRepos() {
        repoBox.removeAllViews()
        repoHeader.text = "Repo (${repoData.size})"
        for ((url, d) in repoData) {
            val cb = CheckBox(this)
            val short = url.removePrefix("https://").removePrefix("http://")
            cb.text = if (d != null) "$short\n${d.third} এক্সটেনশন, ব্যাকআপের সাথে মিলেছে ${d.second.size}"
            else "$short\nপড়া যায়নি"
            cb.textSize = 13f
            cb.isEnabled = d != null
            cb.isChecked = url in repoSel
            cb.setOnCheckedChangeListener { _, c ->
                if (c) repoSel.add(url) else repoSel.remove(url)
                renderExt()
            }
            repoBox.addView(cb, matchParent())
        }
    }

    private fun computeWanted() {
        val b = bk ?: return
        val srcMap = HashMap<Long, Pair<String, Ext>>()
        for (url in repoData.keys) {
            if (url !in repoSel) continue
            val d = repoData[url] ?: continue
            for (e in d.second) for (sid in e.ids) if (!srcMap.containsKey(sid)) srcMap[sid] = Pair(d.first, e)
        }
        val w = HashMap<String, Pair<String, Ext>>()
        val miss = ArrayList<Long>()
        for (sid in b.ids.sorted()) {
            val hit = srcMap[sid]
            if (hit == null) miss.add(sid) else if (!w.containsKey(hit.second.apk)) w[hit.second.apk] = hit
        }
        wanted = w.values.sortedBy { it.second.title.lowercase() }
        missingIds = miss
    }

    private fun renderExt() {
        val b = bk ?: return
        computeWanted()
        extBox.removeAllViews()
        extHeader.text = "Extension (${wanted.size})"
        for ((_, ext) in wanted) {
            val cb = CheckBox(this)
            val names = ext.ids.mapNotNull { b.names[it] }.distinct()
            val src = if (names.isEmpty()) "" else " • " + names.take(3).joinToString(", ") + (if (names.size > 3) "…" else "")
            cb.text = ext.title + "\n" + ext.apk + src
            cb.textSize = 14f
            cb.isChecked = ext.apk !in deselected
            cb.setOnCheckedChangeListener { _, c ->
                if (c) deselected.remove(ext.apk) else deselected.add(ext.apk)
                updateCount()
            }
            extBox.addView(cb, matchParent())
        }
        val sb = StringBuilder()
        if (missingIds.isNotEmpty()) {
            sb.append("নির্বাচিত repo-গুলোতে নেই (${missingIds.size}):\n")
            for (sid in missingIds) sb.append("• ").append(b.names[sid] ?: sid.toString()).append("\n")
        }
        missingView.text = sb.toString()
        updateCount()
    }

    private fun updateCount() {
        val n = wanted.count { it.second.apk !in deselected }
        dlBtn.text = "ডাউনলোড করুন ($n)"
        dlBtn.isEnabled = n > 0
    }

    // ------------------------------------------------------ downloading --
    private val dl = MediaStore.Downloads.EXTERNAL_CONTENT_URI
    private val relPath = "Download/extensions"

    private fun log(s: String) {
        val m = mode
        runOnUiThread {
            val tv = if (m == 1) lLog else logView
            val sc = if (m == 1) lScroll else scroll
            tv.append(s + "\n")
            sc.post { sc.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun findUri(name: String): Uri? {
        contentResolver.query(
            dl, arrayOf(MediaStore.Downloads._ID),
            MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + " LIKE ?",
            arrayOf(name, "$relPath%"), null
        )?.use { c ->
            if (c.moveToFirst()) return ContentUris.withAppendedId(dl, c.getLong(0))
        }
        return null
    }

    private fun newFile(name: String, mime: String): Uri? {
        val v = ContentValues()
        v.put(MediaStore.Downloads.DISPLAY_NAME, name)
        v.put(MediaStore.Downloads.MIME_TYPE, mime)
        v.put(MediaStore.Downloads.RELATIVE_PATH, relPath)
        v.put(MediaStore.Downloads.IS_PENDING, 1)
        return contentResolver.insert(dl, v)
    }

    private fun markDone(uri: Uri) {
        val v = ContentValues()
        v.put(MediaStore.Downloads.IS_PENDING, 0)
        contentResolver.update(uri, v, null, null)
    }

    private fun downloadApk(url: String, name: String) {
        val uri = newFile(name, "application/vnd.android.package-archive")
            ?: throw RuntimeException("ফাইল বানানো যায়নি")
        try {
            val c = httpOpen(url)
            c.inputStream.use { i ->
                contentResolver.openOutputStream(uri)!!.use { o -> i.copyTo(o) }
            }
            markDone(uri)
        } catch (e: Throwable) {
            contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun downloadItems(items: List<Pair<String, Ext>>): DlResult {
        val done = ArrayList<String>()
        val failed = ArrayList<Pair<String, Ext>>()
        val failedText = ArrayList<String>()
        val doneApks = ArrayList<String>()
        var n = 0
        for (item in items) {
            n++
            val (base, ext) = item
            val apk = ext.apk
            val label = ext.title + "  (" + apk + ")"
            if (findUri(apk) != null) {
                log("[$n/${items.size}] আগেই আছে: $apk")
                done.add(label); doneApks.add(apk)
                continue
            }
            val url = if (ext.url.isNotEmpty()) ext.url
            else base + "/apk/" + URLEncoder.encode(apk, "UTF-8").replace("+", "%20")
            try {
                log("[$n/${items.size}] নামানো হচ্ছে: $apk")
                downloadApk(url, apk)
                done.add(label); doneApks.add(apk)
            } catch (e: Throwable) {
                failed.add(item)
                failedText.add("$apk  $url  (${e.message})")
                log("   ব্যর্থ: ${e.message}")
            }
        }
        return DlResult(done, failed, failedText, doneApks)
    }

    private fun writeReport() {
        val sb = StringBuilder()
        sb.append("== পাওয়া/নামানো (${rDone.size}) ==\n").append(rDone.joinToString("\n")).append("\n\n")
        if (rSkipped.isNotEmpty()) sb.append("== আপনি বাদ দিয়েছেন (${rSkipped.size}) ==\n").append(rSkipped.joinToString("\n")).append("\n\n")
        sb.append("== কোনো repo-তে নেই (${rMissing.size}) ==\n").append(rMissing.joinToString("\n")).append("\n")
        if (rFailed.isNotEmpty()) sb.append("\n== ডাউনলোড ব্যর্থ (${rFailed.size}) ==\n").append(rFailed.joinToString("\n")).append("\n")
        findUri("report.txt")?.let { contentResolver.delete(it, null, null) }
        newFile("report.txt", "text/plain")?.let { u ->
            contentResolver.openOutputStream(u)!!.use { it.write(sb.toString().toByteArray()) }
            markDone(u)
        }
        log("")
        log(sb.toString())
        log("ফোল্ডার: Download/extensions  (report.txt সহ)")
    }

    private fun afterDownload(r: DlResult) {
        failedDl = r.failed
        rFailed = r.failedText
        writeReport()
        runOnUiThread {
            busy = false
            pickBtn.isEnabled = true
            retryBtn.isEnabled = true
            updateInstallBtn()
            if (r.failed.isEmpty()) {
                setRetry(0, null)
                status.text = "শেষ। নতুন করে শুরু করতে ব্যাকআপ আবার বাছাই করুন।"
            } else {
                setRetry(2, "ব্যর্থ ডাউনলোড আবার চেষ্টা করুন (${r.failed.size})")
                status.text = "কিছু ডাউনলোড ব্যর্থ হয়েছে। নেট ঠিক থাকলে আবার চেষ্টা করুন।"
            }
        }
    }

    // ------------------------------------------- install-only page --
    private fun fmtSize(s: Long): String =
        if (s <= 0) "" else if (s >= 1048576) String.format("%.1f MB", s / 1048576.0) else "${s / 1024} KB"

    private fun addLocal(data: Intent) {
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        data.data?.let { if (it !in uris) uris.add(it) }
        var added = 0
        var skipped = 0
        for (u in uris) {
            if (localItems.any { it.uri == u }) continue
            var nm: String? = null
            var size = -1L
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        nm = c.getString(0)
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            } catch (e: Exception) {
            }
            val name = nm ?: u.lastPathSegment ?: "file.apk"
            if (!name.endsWith(".apk", ignoreCase = true)) {
                skipped++
                continue
            }
            localItems.add(LocalApk(name, u, size))
            added++
        }
        localItems.sortBy { it.name.lowercase() }
        renderLocal()
        var msg = "$added টা APK যোগ হয়েছে, মোট ${localItems.size}।"
        if (skipped > 0) msg += " $skipped টা ফাইল APK নয় বলে বাদ গেছে।"
        lStatus.text = msg
        lScroll.scrollTo(0, 0)
    }

    private fun renderLocal() {
        lBox.removeAllViews()
        lTools.visibility = if (localItems.isEmpty()) View.GONE else View.VISIBLE
        for (a in localItems) {
            val cb = CheckBox(this)
            val sz = fmtSize(a.size)
            cb.text = if (sz.isEmpty()) a.name else a.name + "\n" + sz
            cb.textSize = 14f
            cb.isChecked = a.uri !in lDesel
            cb.setOnCheckedChangeListener { _, c ->
                if (c) lDesel.remove(a.uri) else lDesel.add(a.uri)
                updateLocalCount()
            }
            lBox.addView(cb, matchParent())
        }
        updateLocalCount()
    }

    private fun updateLocalCount() {
        val n = localItems.count { it.uri !in lDesel }
        installLocalBtn.text = "Shizuku দিয়ে ইনস্টল করুন ($n)"
        installLocalBtn.isEnabled = n > 0
    }

    // ------------------------------------------------- install (Shizuku) --
    private fun updateInstallBtn() {
        installBtn.visibility = if (rApks.isEmpty()) View.GONE else View.VISIBLE
        installBtn.text = "Shizuku দিয়ে সব ইনস্টল করুন (${rApks.size})"
    }

    private fun installAll() {
        if (busy || rApks.isEmpty()) return
        val items = rApks.mapNotNull { n -> findUri(n)?.let { InstallItem(n, it) } }
        startInstall(items)
    }

    private fun startInstall(items: List<InstallItem>) {
        if (busy || items.isEmpty()) return
        pendingInstall = items
        val st = activeStatus()
        try {
            if (!Shizuku.pingBinder()) {
                st.text = "Shizuku চালু নেই। Shizuku অ্যাপ খুলে Start করুন, তারপর আবার চাপুন।"
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                runInstall(items)
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                st.text = "Shizuku অ্যাপে গিয়ে এই অ্যাপকে অনুমতি দিন, তারপর আবার চাপুন।"
            } else {
                st.text = "Shizuku-র অনুমতি দিন..."
                Shizuku.requestPermission(100)
            }
        } catch (e: Throwable) {
            st.text = "Shizuku পাওয়া যায়নি: $e"
        }
    }

    private fun shq(s: String) = "'" + s.replace("'", "'\"'\"'") + "'"

    private fun shizukuExec(cmd: String, input: java.io.InputStream? = null): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        if (input != null) {
            p.outputStream.use { o -> input.copyTo(o) }   // stream the APK into `pm install -S`
        }
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return Pair(code, (out + "\n" + err).trim())
    }

    private fun setInstallUiEnabled(en: Boolean) {
        pickBtn.isEnabled = en
        pickApkBtn.isEnabled = en
        retryBtn.isEnabled = en
        installBtn.isEnabled = en
        installLocalBtn.isEnabled = en
    }

    private fun runInstall(items: List<InstallItem>) {
        if (busy) return
        val list = ArrayList(items)
        if (list.isEmpty()) return
        busy = true
        setInstallUiEnabled(false)
        activeStatus().text = "ইনস্টল চলছে..."
        if (mode == 1) {
            lLog.text = ""
            lLog.visibility = View.VISIBLE
        }
        log("--- Shizuku দিয়ে ইনস্টল ---")
        Thread {
            var ok = 0
            val bad = ArrayList<String>()
            for ((i, item) in list.withIndex()) {
                log("[${i + 1}/${list.size}] ইনস্টল: ${item.name}")
                try {
                    val u = item.uri
                    var size = try {
                        contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } ?: -1L
                    } catch (e: Exception) {
                        -1L
                    }
                    val (code, out) = if (size > 0) {
                        contentResolver.openInputStream(u)!!.use { ins ->
                            shizukuExec("pm install -r -S $size", ins)
                        }
                    } else {
                        // সাইজ জানা না গেলে মেমোরিতে পড়ে নিই
                        val bytes = contentResolver.openInputStream(u)!!.use { it.readBytes() }
                        size = bytes.size.toLong()
                        shizukuExec("pm install -r -S $size", bytes.inputStream())
                    }
                    if (code == 0 && out.contains("Success")) {
                        ok++
                    } else {
                        val msg = out.lines().filter { it.isNotBlank() }.take(6).joinToString(" | ").take(500).ifEmpty { "code $code" }
                        bad.add("${item.name} : $msg")
                        log("   ব্যর্থ: $msg")
                    }
                } catch (e: Throwable) {
                    bad.add("${item.name} : $e")
                    log("   ব্যর্থ: $e")
                }
            }
            log("")
            log("ইনস্টল শেষ: $ok সফল, ${bad.size} ব্যর্থ")
            for (b in bad) log("• $b")
            runOnUiThread {
                busy = false
                setInstallUiEnabled(true)
                updateLocalCount()
                activeStatus().text = "ইনস্টল শেষ: $ok সফল, ${bad.size} ব্যর্থ।"
            }
        }.start()
    }

    private fun startDownload() {
        if (busy) return
        val b = bk ?: return
        val chosen = wanted.filter { it.second.apk !in deselected }
        if (chosen.isEmpty()) return
        rSkipped = wanted.filter { it.second.apk in deselected }.map { it.second.title + "  " + it.second.apk }
        rMissing = missingIds.map { (b.names[it] ?: "(নাম নেই)") + "  " + it }
        rDone.clear()
        rApks.clear()
        busy = true
        pickBtn.isEnabled = false
        dlBtn.visibility = View.GONE
        setRetry(0, null)
        showListViews(false)
        logView.text = ""
        logView.visibility = View.VISIBLE
        installBtn.visibility = View.GONE
        status.text = "ডাউনলোড চলছে..."
        Thread {
            try {
                val r = downloadItems(chosen)
                rDone.addAll(r.done)
                rApks.addAll(r.doneApks.filter { it !in rApks })
                afterDownload(r)
            } catch (e: Throwable) {
                log("ত্রুটি: $e")
                runOnUiThread {
                    busy = false
                    pickBtn.isEnabled = true
                }
            }
        }.start()
    }

    private fun retryDownloads() {
        val items = failedDl
        if (items.isEmpty()) return
        busy = true
        pickBtn.isEnabled = false
        retryBtn.isEnabled = false
        status.text = "আবার চেষ্টা হচ্ছে..."
        log("--- আবার চেষ্টা ---")
        Thread {
            try {
                val r = downloadItems(items)
                rDone.addAll(r.done)
                rApks.addAll(r.doneApks.filter { it !in rApks })
                afterDownload(r)
            } catch (e: Throwable) {
                log("ত্রুটি: $e")
                runOnUiThread {
                    busy = false
                    pickBtn.isEnabled = true
                    retryBtn.isEnabled = true
                }
            }
        }.start()
    }
}
